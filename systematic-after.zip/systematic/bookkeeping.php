<?php $page = 'services'; ?>
<?php $sub_page = 'bookkeeping'; ?>
<?php $title = 'Accounting &amp; Bookkeeping - '; ?>
<?php require_once('inc/header.php') ?>

		<div class="content clearfix">
			<div class="colleft clearfix">
				<h2>Accounting &amp; Bookkeeping</h2>
				<img src="/systematic/img/services/bookkeeping.jpg" alt="Accounting &amp; Bookkeeping">
				<p>Earum libero nobis dolor, eos saepe eum quo animi iste. Distinctio mollitia necessitatibus, pariatur amet architecto esse eaque non consectetur. Animi omnis architecto iure, consectetur sequi saepe perferendis, enim sed.</p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem ducimus animi labore totam est optio, odio repudiandae iure officiis esse vero architecto eligendi, vitae error similique dolorem neque unde incidunt.</p>
				<p>Quam dolorum neque ullam dicta velit in accusantium cumque quaerat, ea laudantium facilis. Nihil, amet accusamus quia modi laborum architecto perferendis distinctio non pariatur. Explicabo architecto placeat magnam cumque dolore.</p>				
			</div> <!-- .colleft -->
			<div class="colright clearfix">
				<?php require_once('inc/services-menu.php'); ?>							
			</div> <!-- .colright -->
		</div> <!-- .content -->

		

<?php require_once('inc/footer.php'); ?>
		<footer>
			<div class="footercol">
				<h4>Latest Tweets</h4>
				<div class="tweet">
					<p>
						<a href="#">@namehere</a>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, similique eligendi! Maxime dolorum eaque explicabo quae, numquam nulla!<br>1 day ago
					</p>
				</div> <!-- tweet -->
				<div class="tweet">
					<p>
						<a href="#">@namehere</a>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis, similique eligendi! Maxime dolorum eaque explicabo quae, numquam nulla!<br>1 day ago
					</p>
				</div> <!-- tweet -->
			</div> <!-- footercol -->
						
			<div class="footercol">
				<h4>Quick Links</h4>
				<ul class="quicklinks">
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
					<li><a href="#">This is a link</a></li>
				</ul> <!-- quicklinks -->
			</div> <!-- footercol -->
						
			<div class="footercol">
				<h4>Latest Blog Posts</h4>
				<div class="blogpost">
					<h5>Post Title</h5>
					<div class="postinfo">
						<a href="#">Admin</a>
						domainname.com <br>
						Sunday, 29th May 2016
					</div> <!-- postinfo -->
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt voluptates possimus.</p>
					<a href="#" class="readmore">Read more &raquo;</a>
				</div> <!-- blogpost -->
				<div class="blogpost">
					<h5>Post Title</h5>
					<div class="postinfo">
						<a href="#">Admin</a>
						domainname.com <br>
						Sunday, 29th May 2016
					</div> <!-- postinfo -->
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt voluptates possimus.</p>
					<a href="#" class="readmore">Read more &raquo;</a>
				</div> <!-- blogpost -->
			</div> <!-- footercol -->
						
			<div class="footercol">
				<h4>Contact Us</h4>
				<form action="index.html" class="contact">
					<input type="text" name="name" placeholder="Name">
					<input type="email" name="email" placeholder="Email">
					<input type="text" name="subject" placeholder="Subject">
					<textarea name="message" id="" cols="30" rows="10" placeholder="Message"></textarea>
					<button>Submit</button>
				</form>
			</div> <!-- footercol -->

		</footer>

		<div class="copyrights">
			<div class="left">
				Copyrights &copy; Domain Name. All Rights Reserved
			</div>
			<div class="right">
				Website by: BestJobsLK.COM
			</div>
		</div> <!-- copyrights -->
	</div> <!-- wrapper -->

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.cycle2/2.1.6/jquery.cycle2.min.js"></script>
</body>
</html>
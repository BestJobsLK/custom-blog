<h2>Our Services</h2>
<ul class="services">
	<li> <a href="services/bookkeeping" <?php echo ($sub_page == 'bookkeeping') ? $active : ''; ?>>Accounting &amp; Bookkeeping</a></li>
	<li> <a href="reconciliation.php"  <?php echo ($sub_page == 'reconciliation') ? $active : ''; ?>>Accounts Reconciliation</a></li>
	<li> <a href="reporting.php"  <?php echo ($sub_page == 'reporting') ? $active : ''; ?>>Financial Reporting</a></li>
	<li> <a href="cfo-services.php"  <?php echo ($sub_page == 'cfo-services') ? $active : ''; ?>>CFO Services</a></li>
</ul>